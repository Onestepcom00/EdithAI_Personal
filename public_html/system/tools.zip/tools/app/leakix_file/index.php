<?php
header('Content-Type: application/json');

$filename = isset($_GET['filename']) ? $_GET['filename'] : null;

if ($filename) {
    $response = [
        'message' => "Le fichier n'a pas ete trouver !"
    ];
} else {
    $response = [
        'error' => 'Aucun nom de fichier fourni'
    ];
}

echo json_encode($response,true);
?>